<?php
function redirect()
{
echo '<script ="text/javascript">';
echo 'document.location.href="http://navarachanaa.svvv.edu.in/";';
echo '</script>';
}
?>
